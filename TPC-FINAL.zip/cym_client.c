#include <sys/socket.h> // pour socket(), recv(), send(), connect()
#include <sys/types.h>  // pour socket(), recv(), send(), connect()
#include <stdio.h>      // pour perror(), printf(), fprintf()
#include <arpa/inet.h>  // pour htons(), inet_pton()
#include <stdlib.h>     // pour strtol()
#include <unistd.h>     // pour close()
#include "fonction.h"





#define PORTSERVEUR 8081
#define IPSERVEUR "127.0.0.1"
#define ID "alfred-abdoulaye-djamel-pascal"

int main()
{
  int maSocket;
  struct sockaddr_in coupleIPPortServeur;
  long int adresseIPServeur;
  char lettre;
  char lettreReponse;
  socklen_t longueurServeur;

  if (inet_pton(AF_INET, IPSERVEUR, (void *)&adresseIPServeur) == -1)
  {
    perror("inet_pton");
    return -1;
  }

  // Initialiser les structures a des octets de valeurs 0
  memset(&coupleIPPortServeur, 0, sizeof(struct sockaddr_in));

  // Créer la socket client en mode TCP
  if ((maSocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
  {
    perror("socket");
    return -1;
  }

  // Initialiser l'adresse IP et le numéro de port du serveur
  // socket du domaine reseau
  coupleIPPortServeur.sin_family = AF_INET;
  // adresse IP
  coupleIPPortServeur.sin_addr.s_addr = adresseIPServeur;
  // affecter le numero de port de l'application
  coupleIPPortServeur.sin_port = htons(PORTSERVEUR);

  // Effectuer la demande connexion au serveur
  longueurServeur = sizeof(coupleIPPortServeur);
  if (connect(maSocket, (struct sockaddr *)&coupleIPPortServeur, longueurServeur) == -1)
  {
    perror("connect");
    return -1;
  }

  char *ordre_du_serveur = malloc(5);
  //identification au serveur
  if (envoyer_la_donnees(maSocket,ID) == -1)
  {
    perror("identification aupres du serveur");
    return -1;
  }

    if(recevoir_la_donnees(maSocket,&ordre_du_serveur)==-1){
    perror("identification aupres du serveur");
    return -1;
  }
 
  
  gererLesOrdreServeur(maSocket,ordre_du_serveur);
 
  free(ordre_du_serveur);
  close(maSocket);

  return 0;
}



