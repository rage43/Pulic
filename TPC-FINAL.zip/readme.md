# depandance
- sudo apt-get install libssl-dev pour la librairie

# configuration
 - cle = valeur
 - il est possible de preciser le nombre de fork souhaité fork-10 pour 10 ou fork-50 pour 50


# compilation
    - gcc cym_serveur.c  -lssl -lcrypto && ./a.out
    - gcc cym_client.c  -lssl -lcrypto && ./a.out


# Lab
un reperotire test devra etre créé pour le test et y mettre les ficiers à créé
./test