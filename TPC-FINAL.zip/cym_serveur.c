#include <string.h>     // pour memset()
#include <sys/types.h>  // pour socket(), setsockopt(), bind(), listen(), accept(), recv(), send(), wait()
#include <sys/socket.h> // pour socket(), setsockopt(), bind(),listen(), accept(), recv(), send()
#include <stdio.h>      // pour fprintf(), perror()
#include <arpa/inet.h>  // pour htonl(), htons()
#include <unistd.h>     // pour fork(), close()
#include <sys/wait.h>   // pour wait()
#include <stdlib.h>
#include "fonction.h"

// taille de la file d'attente de demandes de connexion
#define TAILLE_FILE_DATTENTE_CONNEXION 5
// Numéro de port du serveur
#define NUMERO_PORT_SERVEUR 8081

int main()
{
    struct sockaddr_in coupleIPPortServeur;
    struct sockaddr_in coupleIPPortClient;
    int socketConnexion;
    int socketConnectee;
    char *donnees;
    char *commande;

    socklen_t longueurClient;
    int optval;
    char config[MAX_LIGNES][MAX_CARACTERES_PAR_LIGNE] = {0};

    // Mettre en place de l'interception de SIGCHLD émis par les fils
    signal(SIGCHLD, intercepter);

    // Initialiser les structures à des octets de valeurs 0
    memset(&coupleIPPortServeur, 0, sizeof(struct sockaddr_in));

    // Créer la socket serveur en mode TCP
    if ((socketConnexion = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        return -1;
    }

    // Réutiliser le même port en cas d'interruption brutale du serveur
    optval = 1;
    setsockopt(socketConnexion, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

    // Associer la socket serveur à un couple adresse IP, numéro de port
    coupleIPPortServeur.sin_family = AF_INET;
    coupleIPPortServeur.sin_addr.s_addr = htonl(INADDR_ANY);
    coupleIPPortServeur.sin_port = htons(NUMERO_PORT_SERVEUR);
    if (bind(socketConnexion, (struct sockaddr *)(&coupleIPPortServeur), sizeof(struct sockaddr_in)) == -1)
    {
        perror("bind");
        return -1;
    }

    // Créer une file d'attente de demandes de connexion
    if (listen(socketConnexion, TAILLE_FILE_DATTENTE_CONNEXION) == -1)
    {
        perror("listen");
        return -1;
    }

    longueurClient = sizeof(struct sockaddr_in);

    while (1)
    {

        // Accepter une demande de connexion
        socketConnectee = accept(socketConnexion, (struct sockaddr *)(&coupleIPPortClient), &longueurClient);

        if (socketConnectee == -1)
        {
            perror("accept");
        }
        else
        {
            // Créer un fils pour traiter la communication
            if (fork() == 0)
            {
                // Dans le fils
                // Fermer la socket serveur permettant d'effectuer la demande
                close(socketConnexion);
                char *identifiant_client = (char *)malloc(5);
                // Communiquer avec le client :identification
                if (recevoir_la_donnees(socketConnectee, &identifiant_client) == -1)
                {
                    fprintf(stderr, "recevoir_la_donnees : échec\n");
                    close(socketConnectee);
                    return -1;
                }

                // Vérification de l'identifiant et récupération de la commande
                if (verificationIdentifiantEtrucuperationCommande(identifiant_client, &commande) != 0)
                {
                    printf("Le client n'est pas autorisé a communiquer avec le serveur\n");
                    free(commande);
                    free(identifiant_client);
                    return -1;
                }

                envoyer_la_donnees(socketConnectee, commande);

                
                printf("Le client ayant pour identifiant \'%s\' a reçu l'ordre %s\n", identifiant_client, commande);
                gererRetoursClient(socketConnectee, commande, identifiant_client);

                // Fermer dans le fils la socket connectée
                close(socketConnectee);
                free(commande);
                free(identifiant_client);
                return 0;
            }

            // Dans le père
            // Fermer la socket connectée
            close(socketConnectee);
        }
    }
    return 0;
}
